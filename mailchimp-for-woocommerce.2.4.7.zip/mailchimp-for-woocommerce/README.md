# Mailchimp for WooCommerce Wordpress Plugin  

Have a question or need help? Submit an [issue](https://github.com/mailchimp/mc-woocommerce/issues/new?assignees=&labels=investigating&template=bug_report.md&title=%5BBUG%5D+Description+of+Issue).

Also check out our [Wiki](https://github.com/mailchimp/mc-woocommerce/wiki) for documentation on common troubleshooting and features available to developers.
