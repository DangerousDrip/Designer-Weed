/*global QUnit */
jQuery( function() {

	QUnit.module( 'wp.updates' );

	// @todo: Write new tests for update-core.php parts.
} );
