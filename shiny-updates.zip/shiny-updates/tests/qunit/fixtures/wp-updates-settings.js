window._wpShinyUpdatesSettings = {
	'l10n': {
		'updatingAllLabel':          'Updating site...',
		'updatingCoreLabel':         'Updating WordPress...',
		'updatingTranslationsLabel': 'Updating translations...',
		'coreRedirect':              'Note: You will be redirected to the About page after WordPress has been updated.'
	}
};

window._wpUtilSettings = {
	'ajax': {
		'url': '\/wp-admin\/admin-ajax.php'
	}
};
